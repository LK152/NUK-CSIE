class Trie {
    private:    

    public:

}