class TrieNode {
    private: 
        char character;
        bool isWordEnd;

    public:

}