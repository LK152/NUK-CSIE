#include "iostream"
#include "date.h"

using namespace std;

int main() {
    Date date(11, 01, 2024);

    date.displayDate();

    return 0;
}